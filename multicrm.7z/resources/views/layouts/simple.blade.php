@yield('content')

@stack('scripts')
