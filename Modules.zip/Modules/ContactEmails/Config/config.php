<?php

return [
    'name' => 'ContactEmails',

    'entity_private_access' => false,

];
