<?php

return [
    'name' => 'Api',


    'saas' => [
        'defaultRole' => 2
    ]
];
