<?php

return [
    'name' => 'LeadEmails',

    'entity_private_access' => false,

];
