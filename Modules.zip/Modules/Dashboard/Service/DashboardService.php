<?php

namespace Modules\Dashboard\Service;

/**
 * Class DashboardService
 * @package Modules\Dashboard\Service
 */
class DashboardService
{
}
