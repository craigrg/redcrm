var BAP_Dashboard = {

    init: function () {

    },


}

BAP_Dashboard.init();

